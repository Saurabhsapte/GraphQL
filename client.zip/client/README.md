# GraphQL Test Client

## To Run Application
```sh
npm run dev
```

## To View
Open your browser and navigate to:
```
http://localhost:5173
```

## Commands
```sh
npm create vite@latest
npm install @apollo/client graphql
```

## References
- https://www.apollographql.com/docs/react/get-started